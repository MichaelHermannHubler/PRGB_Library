#pragma once


struct Entity {
	int id = -1;
};

void TestUniquePointer();
void TestString();
void Str_Test1();
void Str_Test2();
void Str_Test3();